
  # Recreate Web App Frame

  This is a code bundle for Recreate Web App Frame. The original project is available at https://www.figma.com/design/GK5h8oiIZFm0VBFED36gQ2/Recreate-Web-App-Frame.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  