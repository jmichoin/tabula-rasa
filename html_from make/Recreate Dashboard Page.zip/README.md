
  # Recreate Dashboard Page

  This is a code bundle for Recreate Dashboard Page. The original project is available at https://www.figma.com/design/mh8dKpWApP6aAbof53Fq9W/Recreate-Dashboard-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  